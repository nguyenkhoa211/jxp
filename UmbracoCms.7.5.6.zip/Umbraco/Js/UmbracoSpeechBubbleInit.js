﻿//used by live editing to ensure the speech bubble is initialized after the main js file has been lazy loaded.
//alert("Speech Bubble init: " + InitUmbracoSpeechBubble);
InitUmbracoSpeechBubble();